var searchData=
[
  ['eliminacontatto_0',['eliminaContatto',['../classprogettoingsoftware_1_1model_1_1_rubrica.html#aa0eda867ff6260485a4af2d7828dfc52',1,'progettoingsoftware::model::Rubrica']]],
  ['esportarubrica_1',['esportaRubrica',['../classprogettoingsoftware_1_1model_1_1_gestione_file.html#a5d8442a427b1c1aba5a2fd57b6dbe019',1,'progettoingsoftware::model::GestioneFile']]],
  ['esportlist_2',['esportList',['../classprogettoingsoftware_1_1controller_1_1_rubrica_controller.html#a533de562513e13290a446a903bdb7939',1,'progettoingsoftware::controller::RubricaController']]]
];
