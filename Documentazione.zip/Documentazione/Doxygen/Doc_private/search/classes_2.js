var searchData=
[
  ['gestionefile_0',['GestioneFile',['../classprogettoingsoftware_1_1model_1_1_gestione_file.html',1,'progettoingsoftware::model']]]
];
