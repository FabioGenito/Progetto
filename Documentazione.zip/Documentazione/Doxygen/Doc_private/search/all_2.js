var searchData=
[
  ['del_0',['del',['../classprogettoingsoftware_1_1controller_1_1_rubrica_controller.html#a1d42adbb3a787b852a85ba694ea223a7',1,'progettoingsoftware::controller::RubricaController']]]
];
