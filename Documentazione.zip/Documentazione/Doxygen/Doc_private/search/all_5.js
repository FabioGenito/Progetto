var searchData=
[
  ['importarubrica_0',['importaRubrica',['../classprogettoingsoftware_1_1model_1_1_gestione_file.html#a6fe428721e10cfa495aafaabe8adbf06',1,'progettoingsoftware::model::GestioneFile']]],
  ['importlist_1',['importList',['../classprogettoingsoftware_1_1controller_1_1_rubrica_controller.html#a24afed490cf8692521869a26912e19a8',1,'progettoingsoftware::controller::RubricaController']]],
  ['initialize_2',['initialize',['../classprogettoingsoftware_1_1controller_1_1_rubrica_controller.html#a3a2adb08c6ca30d4f4b674f2f2f71d88',1,'progettoingsoftware::controller::RubricaController']]]
];
