var searchData=
[
  ['rubrica_0',['Rubrica',['../classprogettoingsoftware_1_1model_1_1_rubrica.html',1,'progettoingsoftware::model']]],
  ['rubricacontroller_1',['RubricaController',['../classprogettoingsoftware_1_1controller_1_1_rubrica_controller.html',1,'progettoingsoftware::controller']]]
];
