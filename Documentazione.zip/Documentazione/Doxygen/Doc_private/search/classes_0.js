var searchData=
[
  ['applicazione_0',['Applicazione',['../classprogettoingsoftware_1_1main_1_1_applicazione.html',1,'progettoingsoftware::main']]]
];
