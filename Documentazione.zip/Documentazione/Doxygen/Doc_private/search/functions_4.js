var searchData=
[
  ['getcognome_0',['getCognome',['../classprogettoingsoftware_1_1model_1_1_contatto.html#ac3cdc48089bb31d08cffdc8b83d5e3e9',1,'progettoingsoftware::model::Contatto']]],
  ['getcontatti_1',['getContatti',['../classprogettoingsoftware_1_1model_1_1_rubrica.html#adb5c5af6bc169887f2de2b595139c187',1,'progettoingsoftware::model::Rubrica']]],
  ['getmail_2',['getMail',['../classprogettoingsoftware_1_1model_1_1_contatto.html#a9095fb5a22be7f66669b2e9220ef0109',1,'progettoingsoftware::model::Contatto']]],
  ['getnome_3',['getNome',['../classprogettoingsoftware_1_1model_1_1_contatto.html#a1a72e56aeb8338d469ecfd75add49143',1,'progettoingsoftware::model::Contatto']]],
  ['getnum_4',['getNum',['../classprogettoingsoftware_1_1model_1_1_contatto.html#adf6913e710967afba42c27deaa521ded',1,'progettoingsoftware::model::Contatto']]]
];
