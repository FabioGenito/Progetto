var searchData=
[
  ['search_0',['search',['../classprogettoingsoftware_1_1controller_1_1_rubrica_controller.html#a6062bcfe3d7c053fc90862663b5ecd1d',1,'progettoingsoftware::controller::RubricaController']]],
  ['setcognome_1',['setCognome',['../classprogettoingsoftware_1_1model_1_1_contatto.html#a981082047b222de8d9651d145fcd4401',1,'progettoingsoftware::model::Contatto']]],
  ['setmail_2',['setMail',['../classprogettoingsoftware_1_1model_1_1_contatto.html#a90461876f44302b76b2dc883fd71d2b1',1,'progettoingsoftware::model::Contatto']]],
  ['setnome_3',['setNome',['../classprogettoingsoftware_1_1model_1_1_contatto.html#a298e0e1ce2d764ec8e73e2c5a3e1d8bc',1,'progettoingsoftware::model::Contatto']]],
  ['setnum_4',['setNum',['../classprogettoingsoftware_1_1model_1_1_contatto.html#a40c2f35a02d1ae4ef544256e3c54bd17',1,'progettoingsoftware::model::Contatto']]]
];
