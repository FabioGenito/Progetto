var searchData=
[
  ['contatto_0',['Contatto',['../classprogettoingsoftware_1_1model_1_1_contatto.html',1,'progettoingsoftware::model']]]
];
