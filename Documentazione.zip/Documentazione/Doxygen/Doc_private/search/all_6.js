var searchData=
[
  ['mod_0',['mod',['../classprogettoingsoftware_1_1controller_1_1_rubrica_controller.html#a8ca0b24e601c40678c78312c16f2466b',1,'progettoingsoftware::controller::RubricaController']]],
  ['modificacontatto_1',['modificaContatto',['../classprogettoingsoftware_1_1model_1_1_rubrica.html#a3f017171c9248d2a8b519653c309508e',1,'progettoingsoftware::model::Rubrica']]]
];
