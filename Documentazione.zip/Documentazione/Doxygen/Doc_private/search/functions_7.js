var searchData=
[
  ['ricercacontatto_0',['ricercaContatto',['../classprogettoingsoftware_1_1model_1_1_rubrica.html#aadee3c707f94d5a6e514de11c575153c',1,'progettoingsoftware::model::Rubrica']]],
  ['rubrica_1',['Rubrica',['../classprogettoingsoftware_1_1model_1_1_rubrica.html#a2e0993205fee1f856c1c59bba42b6cfa',1,'progettoingsoftware::model::Rubrica']]]
];
