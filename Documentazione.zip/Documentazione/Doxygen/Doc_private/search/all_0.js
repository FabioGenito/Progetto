var searchData=
[
  ['add_0',['add',['../classprogettoingsoftware_1_1controller_1_1_rubrica_controller.html#a3907620071c24b549331b8ee4cea6995',1,'progettoingsoftware::controller::RubricaController']]],
  ['aggiungicontatto_1',['aggiungiContatto',['../classprogettoingsoftware_1_1model_1_1_rubrica.html#aa0b951248f3a9a1cc766605dc52520a9',1,'progettoingsoftware::model::Rubrica']]],
  ['applicazione_2',['Applicazione',['../classprogettoingsoftware_1_1main_1_1_applicazione.html',1,'progettoingsoftware::main']]]
];
