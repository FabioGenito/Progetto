var searchData=
[
  ['setcognome_0',['setCognome',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_contatto.html#ab47f8f3f5e3c20e6628d3b01a5a0f2fa',1,'com::mycompany::testfunzionante::model::Contatto']]],
  ['setmail_1',['setMail',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_contatto.html#ae50808438a0d5e68dc72253a91a1ac1b',1,'com::mycompany::testfunzionante::model::Contatto']]],
  ['setnome_2',['setNome',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_contatto.html#abb9ae1f5b261552fa9115f63fc5537e2',1,'com::mycompany::testfunzionante::model::Contatto']]],
  ['setnumero_3',['setNumero',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_contatto.html#a7a9c664522dc1f20d4ab88428bb42855',1,'com::mycompany::testfunzionante::model::Contatto']]]
];
