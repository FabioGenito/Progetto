var searchData=
[
  ['ordinatabella_0',['ordinaTabella',['../classcom_1_1mycompany_1_1testfunzionante_1_1controller_1_1_rubrica_controller.html#a87849cde66bbb5f727cbdd6d7fc9c162',1,'com::mycompany::testfunzionante::controller::RubricaController']]]
];
