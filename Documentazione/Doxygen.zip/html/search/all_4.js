var searchData=
[
  ['importalista_0',['importaLista',['../classcom_1_1mycompany_1_1testfunzionante_1_1controller_1_1_rubrica_controller.html#a181f2d101cdc93758e0835f90da67e88',1,'com::mycompany::testfunzionante::controller::RubricaController']]],
  ['importarubrica_1',['importaRubrica',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_gestione_file.html#a1e1289f078313984cc3e55b7f7e19dcc',1,'com::mycompany::testfunzionante::model::GestioneFile']]],
  ['initialize_2',['initialize',['../classcom_1_1mycompany_1_1testfunzionante_1_1controller_1_1_rubrica_controller.html#ac10876b34d6d0690620405d5b4c05192',1,'com::mycompany::testfunzionante::controller::RubricaController']]]
];
