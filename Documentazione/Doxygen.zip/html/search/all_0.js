var searchData=
[
  ['aggiungi_0',['aggiungi',['../classcom_1_1mycompany_1_1testfunzionante_1_1controller_1_1_rubrica_controller.html#a3153ecf63710eee1fe90d6efb791150f',1,'com::mycompany::testfunzionante::controller::RubricaController']]],
  ['aggiungicontatto_1',['aggiungiContatto',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_rubrica.html#a195a54a8dc7f90f1649ce99ff3cc12b4',1,'com::mycompany::testfunzionante::model::Rubrica']]],
  ['app_2',['App',['../classcom_1_1mycompany_1_1testfunzionante_1_1_app.html',1,'com::mycompany::testfunzionante']]]
];
