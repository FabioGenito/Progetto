var searchData=
[
  ['gestionefile_0',['GestioneFile',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_gestione_file.html',1,'com::mycompany::testfunzionante::model']]]
];
