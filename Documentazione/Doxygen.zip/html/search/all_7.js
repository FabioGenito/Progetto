var searchData=
[
  ['pulisci_0',['pulisci',['../classcom_1_1mycompany_1_1testfunzionante_1_1controller_1_1_rubrica_controller.html#a4c61cb7495d8156f8c9299392e86d219',1,'com::mycompany::testfunzionante::controller::RubricaController']]]
];
