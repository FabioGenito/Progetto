var searchData=
[
  ['getcognome_0',['getCognome',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_contatto.html#aec6d4c475c0a86ea79fb73ff2e2828b0',1,'com::mycompany::testfunzionante::model::Contatto']]],
  ['getcontatti_1',['getContatti',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_rubrica.html#acb4254ea1bc22e4d93343792b0f65e8a',1,'com::mycompany::testfunzionante::model::Rubrica']]],
  ['getmail_2',['getMail',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_contatto.html#a0ed1c81c4a3fd23b6b8cb38f5295a7c8',1,'com::mycompany::testfunzionante::model::Contatto']]],
  ['getnome_3',['getNome',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_contatto.html#a05add697f29880d45f711d64485c05da',1,'com::mycompany::testfunzionante::model::Contatto']]],
  ['getnumero_4',['getNumero',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_contatto.html#a916c35ee30ecd8c170ff4183a5580df7',1,'com::mycompany::testfunzionante::model::Contatto']]]
];
