var searchData=
[
  ['eliminacontatto_0',['eliminaContatto',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_rubrica.html#a85592fbaac5e3ecbc4b56417a9794529',1,'com::mycompany::testfunzionante::model::Rubrica']]],
  ['esportalista_1',['esportaLista',['../classcom_1_1mycompany_1_1testfunzionante_1_1controller_1_1_rubrica_controller.html#ae9e179bb5f44112a008e1213627928f3',1,'com::mycompany::testfunzionante::controller::RubricaController']]],
  ['esportarubrica_2',['esportaRubrica',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_gestione_file.html#a7995814f8346c77cec481d3147e21545',1,'com::mycompany::testfunzionante::model::GestioneFile']]]
];
