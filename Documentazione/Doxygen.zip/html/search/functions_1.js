var searchData=
[
  ['cerca_0',['cerca',['../classcom_1_1mycompany_1_1testfunzionante_1_1controller_1_1_rubrica_controller.html#a4a4417640cd126a2d380b89ee7bea8e3',1,'com::mycompany::testfunzionante::controller::RubricaController']]],
  ['contatto_1',['Contatto',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_contatto.html#aef12e693787529d751180a64ef5a66ee',1,'com::mycompany::testfunzionante::model::Contatto']]],
  ['conteggiocontatti_2',['conteggioContatti',['../classcom_1_1mycompany_1_1testfunzionante_1_1controller_1_1_rubrica_controller.html#a9ebd263a5dbee433ea07c32fba18ef11',1,'com::mycompany::testfunzionante::controller::RubricaController']]]
];
