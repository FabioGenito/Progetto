var searchData=
[
  ['verifica_0',['Verifica',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_verifica.html',1,'com::mycompany::testfunzionante::model']]]
];
