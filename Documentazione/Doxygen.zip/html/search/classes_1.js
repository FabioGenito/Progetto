var searchData=
[
  ['contatto_0',['Contatto',['../classcom_1_1mycompany_1_1testfunzionante_1_1model_1_1_contatto.html',1,'com::mycompany::testfunzionante::model']]]
];
